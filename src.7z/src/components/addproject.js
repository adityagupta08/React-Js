import React, { Component } from 'react';
import uuid from 'uuid';

class AddProject extends Component {

    constructor(){
        super();
        this.state={
            newProject:{}
        }
    }

    static defaultProps ={
        categories:['select Category','Web Design','Web Dev','Mobile Dev']
    }
    handleSubmit(e)
    {
        if(this.refs.title.value==="")
        {
           alert("Dont you have title or what?");
        }
        else
        {
            this.setState({
                newProject: {
                    id:uuid.v4(),
                    title:this.refs.title.value,
                    category:this.refs.category.value,
                    projectManagerq:this.refs.projectManager.value
                }
            }, function(){
                    console.log(this.state);
                    console.log(this.state.newProject.id);
                    this.props.addProject(this.state.newProject);
                }
                );
        }
        console.log("Submitted!" +this.refs.title.value);
        e.preventDefault();
    }

// defaultprops allow to access categories value in props of render method 
// it assing it value to the props 

  render() {


let categoryOptions=this.props.categories.map(category=>{
    return<option key={category} value={category}>{category}</option>

});



    return (
        <div>
            <h3>Add Project</h3>
            <form onSubmit={this.handleSubmit.bind(this)}>
                <div>
                    <label>Title</label><br />
                    <input type="text" ref="title" />   <br/>   <br/>

                </div>
                <div>
                    <label>Category</label><br />
                    {/*<input type="text" ref="title" />*/}
                    <select ref="category">
                        {categoryOptions}
                    </select>
                    <br/>


                </div>
                <div>
                    <label>Project Manager</label><br />
                    <input type="text" ref="projectManager" />   <br/>   <br/>

                </div>
               
                
                <input type="submit"  value="Submit Details"/>


            </form>
   <br/>   <br/>
        </div>
    );
  }
}

export default AddProject;
