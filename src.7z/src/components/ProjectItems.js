import React, { Component } from 'react';
import ProjectItemsDetails from './ProjectItemsDetails'

class ProjectItems extends Component {

  deleteProject(id){
   console.log("will be deletd from project Item");
   this.props.onDelete(id);

    
  }
  render() {
    let projectItemsDetails;
      if(this.props.projects.details){
          projectItemsDetails=this.props.projects.details.map(projectDetails=>
          {//console.log(projectDetails);
            return(
            <ProjectItemsDetails key={projectDetails.id} projectDetails={projectDetails}/>
          );
          }
        );
          
      }
    return (
      <ul>
        <li>{this.props.projects.id} <a href="#" className="glyphicon glyphicon-trash" onClick={this.deleteProject.bind(this,this.props.projects.id)}></a> </li>
        <li>{this.props.projects.title}</li>
        <li>{this.props.projects.category}</li>
        <li>{this.props.projects.projectManager}</li>
        <li></li>
        {projectItemsDetails}
      </ul>
    );
  }
}

export default ProjectItems;
