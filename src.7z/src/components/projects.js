import React, { Component } from 'react';
import ProjectItems from './ProjectItems'
import PropTypes from 'prop-types'

class Projects extends Component {

deleteProject(id){
  this.props.onDelete(id);
}






  render() {
      let projectItems;
      if(this.props.projects){
          projectItems=this.props.projects.map(project=>
          {//console.log(project);
            return(
            <ProjectItems key={project.title} projects={project} onDelete={this.deleteProject.bind(this)}/>
          );
          }
        );
          
      }
    return (
      <div className="pro">
        My Projects Component 
        
          <h3> Newly Added projects</h3>
          {projectItems}
          
          {/*</table>*/}
      </div>
    );
  }

 
 




}

  Projects.propTypes={
    projects:PropTypes.array,
    onDelete:PropTypes.func
  }

export default Projects;
